# Dynamic Databricks Unity Catalog API

A reusable FastAPI service for allow-listed Unity Catalog tables. It supports:
- Dynamic table schema lookup
- Single-record insert
- Batch insert
- Read through a SQL Warehouse
- Partial update by configured primary key
- Databricks Job status lookup
- No DELETE endpoint

## 1. Important design notes

This is a production-oriented starter, not a turnkey deployment. Before production:
1. Move the duplicated allow-list in `api/registry.py` and the worker into one governed config source (or generate both from a single versioned config artifact).
2. Replace the static API key with your organization's OAuth/JWT identity provider and propagate the authenticated principal for auditing.
3. Add idempotency keys, audit logging, structured logs, request-size controls, rate limits, retries, and alerting.
4. Add schema-aware type validation. The worker uses the actual target Spark schema when constructing the source DataFrame, but client-side API validation currently checks names/allow-lists, not every Spark type constraint.
5. Configure job concurrency and write serialization for tables where duplicate primary keys must be prevented. Delta tables do not automatically enforce primary-key uniqueness.
6. For large batch requests, upload the payload to a Unity Catalog Volume or cloud object storage and pass a reference to the job; do not send large data in job parameters.
7. The read endpoint currently returns a bounded first result page. Add chunk pagination for larger result sets.

## 2. Local setup

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Fill `.env` with:
- Databricks workspace URL
- Service principal OAuth client ID and secret
- SQL Warehouse ID
- Databricks Job ID
- A long random API key

Run:
```bash
uvicorn api.main:app --reload
```
Open `http://127.0.0.1:8000/docs`.

## 3. Databricks setup

1. Create or identify a Unity Catalog catalog/schema and Delta tables.
2. Create a Databricks service principal for this application.
3. Grant the service principal `USE CATALOG`, `USE SCHEMA`, `SELECT` on tables, and `MODIFY` on write-target tables. `MODIFY` is needed for insert/update. Grant only on the intended schemas/tables.
4. Create a SQL Warehouse and grant the service principal `CAN USE`.
5. Upload `databricks/dynamic_table_worker.py` to the workspace as a Python notebook.
6. Create a Job with one Notebook task pointing to that notebook.
7. Add job parameters with these exact names and defaults:
   - `table_key` = `employees`
   - `operation` = `insert`
   - `records_json` = `[]`
   - `primary_key_json` = `{}`
8. Set the job's run-as identity to the service principal (or another approved non-human identity).
9. Copy the Job ID and SQL Warehouse ID into `.env`.

The API calls `jobs.run_now(job_id=..., job_parameters={...})`. Job-level parameters are passed to the notebook widgets.

## 4. Registry configuration

Edit `api/registry.py` and the worker `TABLES` mapping together. Each table needs:
- A stable API key
- Fully qualified `catalog.schema.table`
- Primary key column(s)
- Required insert columns
- Allowed insert/update/read columns
- Enabled flag

Do not let clients supply arbitrary SQL or a raw table identifier.

## 5. Example API calls

Header on every protected request:
`X-API-Key: <API_KEY>`

### List configured tables
```http
GET /api/v1/tables
```

### Get schema
```http
GET /api/v1/tables/employees/schema
```

### Insert one
```http
POST /api/v1/tables/employees/records
Content-Type: application/json

{"data":{"employee_id":101,"employee_name":"John","salary":75000,"department":"IT"}}
```

### Batch insert
```http
POST /api/v1/tables/employees/records/batch
Content-Type: application/json

{"records":[
  {"employee_id":102,"employee_name":"Mary","salary":80000},
  {"employee_id":103,"employee_name":"David","salary":85000}
]}
```

### Read through SQL Warehouse (synchronous)
```http
GET /api/v1/tables/employees/records?limit=100&offset=0&mode=sql
```

### Read through Databricks Job (asynchronous)
```http
GET /api/v1/tables/employees/records?limit=100&offset=0&mode=job
```
The job mode returns a run ID. Poll `/api/v1/jobs/{run_id}`; after success, the response includes `notebook_output`. Use this for slower/bulk reads. The worker returns bounded JSON notebook output, so it is not suitable for very large result sets; use a governed Volume/object-storage export for those.

### Partial update
```http
PATCH /api/v1/tables/employees/records
Content-Type: application/json

{"primary_key":{"employee_id":101},"updates":{"salary":95000}}
```

### Check job status
```http
GET /api/v1/jobs/<run_id>
```

## 6. Test with curl

```bash
curl -H "X-API-Key: <API_KEY>" http://127.0.0.1:8000/api/v1/tables/employees/schema
```

## 7. Operational semantics

- `POST` insert is implemented as Delta MERGE with `WHEN NOT MATCHED INSERT` only. Existing keys are left unchanged (no update). This avoids a check-then-append race, but it does not create a database-enforced unique constraint.
- `PATCH` uses `WHEN MATCHED UPDATE` and changes only supplied columns. If no key matches, no row is changed.
- The API returns `SUBMITTED` and a run ID. That is not proof that the write succeeded. Poll `/api/v1/jobs/{run_id}` until the run reaches a terminal state.
- Read supports SQL Warehouse mode (`mode=sql`) and asynchronous Job mode (`mode=job`). Job mode returns bounded notebook output; for large result sets, write to a governed Volume or cloud storage and return a download reference instead.
- No delete operation exists.

## 8. Databricks references

- Jobs API: https://docs.databricks.com/api/workspace/jobs/runNow
- SQL Statement Execution API: https://docs.databricks.com/api/statement-execution
- Unity Catalog privileges: https://docs.databricks.com/aws/en/data-governance/unity-catalog/access-control/privileges-reference
- Delta Lake MERGE: https://docs.databricks.com/aws/en/delta/merge


## 9. Deploy the FastAPI service as a Databricks App

This project now includes `app.yaml` and `run.py` for Databricks Apps. The app runs FastAPI on the port supplied by Databricks and uses the app's managed OAuth identity. Do not put client secrets in the deployed project.

### A. Create the Databricks Job first

1. Upload `databricks/dynamic_table_worker.py` to the workspace as a Python notebook.
2. Create a Lakeflow Job with a notebook task pointing to that notebook.
3. Add job parameters: `table_key`, `operation`, `records_json`, `primary_key_json`.
4. Set the Job's **Run as** identity to a dedicated service principal that has the required Unity Catalog privileges.
5. Test the job manually with a small insert/update payload.
6. Keep the Job ID; you will attach this job as an app resource.

The job's Run as identity performs the Spark/Delta write. The app identity only submits and monitors the job.

### B. Create the Databricks App

1. In the workspace, open the app switcher and choose **Databricks Apps**.
2. Create an app named `dynamic-table-api` (lowercase and hyphenated).
3. Upload the whole project folder, including `api/`, `app.yaml`, `run.py`, and `requirements.txt`, to a workspace folder.
4. In the app's resources section, add:
   - **Job**: select the job created above; permission **Can manage run**; resource key `dynamic-write-job`.
   - **SQL warehouse**: select the warehouse used for reads; permission **Can use**; resource key `sql-warehouse`.
   - **Secret**: select a secret containing the API key; permission **Can read**; resource key `api-key`.
5. Deploy the app from the uploaded workspace folder.

The resource keys must exactly match the `valueFrom` values in `app.yaml`. Databricks Apps injects the Job ID, warehouse ID, and secret value at runtime. It also injects the app's OAuth client credentials for `WorkspaceClient()`.

### C. Grant Unity Catalog permissions to the Job's Run as identity

The job's Run as service principal needs the actual data permissions. For example:

```sql
GRANT USE CATALOG ON CATALOG main TO `dynamic-job-sp`;
GRANT USE SCHEMA ON SCHEMA main.hr TO `dynamic-job-sp`;
GRANT SELECT, MODIFY ON SCHEMA main.hr TO `dynamic-job-sp`;

GRANT USE SCHEMA ON SCHEMA main.crm TO `dynamic-job-sp`;
GRANT SELECT, MODIFY ON SCHEMA main.crm TO `dynamic-job-sp`;
```

Grant only the required privileges on the schemas/tables that the job is allowed to modify. The app's service principal separately needs `CAN MANAGE RUN` on the Job and `CAN USE` on the SQL warehouse through the app resources. If the app itself directly calls the Tables API for schema metadata, also grant it the required Unity Catalog/table metadata permissions or add the target tables as app resources.

### D. Test after deployment

Open the app URL and test:

- `GET /health`
- `GET /docs`
- `GET /api/v1/tables/employees/schema`
- `POST /api/v1/tables/employees/records`
- `PATCH /api/v1/tables/employees/records`
- `GET /api/v1/jobs/{run_id}`

For protected API routes, include `X-API-Key` with the value stored in the Databricks secret resource.

### E. Important identity distinction

There are two identities:
- **App service principal**: calls Databricks APIs, reads through the SQL warehouse, and triggers/monitors the Job.
- **Job Run as service principal**: executes the notebook and accesses/modifies the Delta tables.

Do not assume the app's permissions automatically become the job's data permissions. Grant each identity only what it needs.

### F. Databricks CLI alternative

After configuring a CLI profile and creating the app/resources, you can deploy from the project directory with:

```bash
databricks sync . /Workspace/Users/<your-user>/dynamic-table-api
databricks apps deploy dynamic-table-api --source-code-path /Workspace/Users/<your-user>/dynamic-table-api
```

Check the installed CLI version's `databricks apps deploy --help` because CLI flags can vary by release. The UI deployment flow above is the simplest first deployment.

## 10. Known starter limitations to resolve before production

- `get_table_metadata()` uses the Databricks Tables API. Ensure the app identity has sufficient metadata visibility for every allow-listed table. Alternatively, replace schema discovery with `DESCRIBE TABLE` through the SQL Warehouse.
- The worker registry and API registry are duplicated. Consolidate them into one governed configuration source before adding many tables.
- The starter's batch worker loops over records. For large batches, stage input in a Unity Catalog Volume and pass a file reference to the Job.
- Delta does not enforce primary-key uniqueness. Design concurrency controls for tables where duplicate keys are unacceptable.
- Add full type/nullability validation, audit records, idempotency keys, request limits, and integration tests before production.
