from databricks.sdk import WorkspaceClient


def workspace_client() -> WorkspaceClient:
    # Databricks Apps injects OAuth credentials for the app's managed
    # service principal. The SDK discovers them from the environment.
    return WorkspaceClient()
