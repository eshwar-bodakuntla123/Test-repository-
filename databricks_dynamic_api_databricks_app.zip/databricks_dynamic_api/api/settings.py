from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    databricks_warehouse_id: str
    databricks_job_id: int
    api_key: str
    max_read_rows: int = 500

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
