from databricks.sdk import WorkspaceClient
from api.settings import settings


def workspace_client() -> WorkspaceClient:
    return WorkspaceClient(
        host=settings.databricks_host,
        client_id=settings.databricks_client_id,
        client_secret=settings.databricks_client_secret,
    )


def to_dict(obj):
    if obj is None:
        return None
    if hasattr(obj, "as_dict"):
        return obj.as_dict()
    if isinstance(obj, dict):
        return obj
    return obj
