from fastapi import Depends, FastAPI, HTTPException, Query
from api.schemas import InsertOneRequest, InsertManyRequest, UpdateRequest
from api.security import require_api_key
from api.service import (
    table_config, get_table_metadata, validate_record, validate_primary_key,
    trigger_write_job, quoted_table_name, sql_statement, read_statement_result,
)
from api.settings import settings

app = FastAPI(
    title="Dynamic Unity Catalog Table API",
    version="1.0.0",
    description="Allow-listed insert, read and partial-update APIs. Delete is intentionally not implemented.",
)


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/api/v1/tables")
def list_tables(_: None = Depends(require_api_key)):
    return [{"key": k, "full_name": v["full_name"]} for k, v in table_config_items()]


def table_config_items():
    from api.registry import TABLES
    return [(k, v) for k, v in TABLES.items() if v.get("enabled")]


@app.get("/api/v1/tables/{table_key}/schema")
def schema(table_key: str, _: None = Depends(require_api_key)):
    return get_table_metadata(table_key)


@app.post("/api/v1/tables/{table_key}/records")
def insert_one(table_key: str, body: InsertOneRequest, _: None = Depends(require_api_key)):
    metadata = get_table_metadata(table_key)
    validate_record(table_key, body.data, "insert", metadata)
    return trigger_write_job(table_key, "insert", [body.data])


@app.post("/api/v1/tables/{table_key}/records/batch")
def insert_many(table_key: str, body: InsertManyRequest, _: None = Depends(require_api_key)):
    metadata = get_table_metadata(table_key)
    for record in body.records:
        validate_record(table_key, record, "insert", metadata)
    return trigger_write_job(table_key, "insert", body.records)


@app.patch("/api/v1/tables/{table_key}/records")
def update_partial(table_key: str, body: UpdateRequest, _: None = Depends(require_api_key)):
    metadata = get_table_metadata(table_key)
    validate_primary_key(table_key, body.primary_key, metadata)
    validate_record(table_key, body.updates, "update", metadata)
    return trigger_write_job(table_key, "update", [body.updates], body.primary_key)


@app.get("/api/v1/tables/{table_key}/records")
def read_records(
    table_key: str,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    mode: str = Query(default="sql", pattern="^(sql|job)$"),
    _: None = Depends(require_api_key),
):
    cfg = table_config(table_key)

    if mode == "job":
        # Async mode: the same configured job runs a bounded read and returns
        # its result through notebook output. Use for slower/large reads, not
        # high-frequency interactive pagination.
        return trigger_write_job(
            table_key,
            "read",
            [{"limit": limit, "offset": offset}],
        )

    allowed = cfg["read_allowed"]
    table = quoted_table_name(cfg["full_name"])
    projection = ", ".join(f"`{c}`" for c in allowed)
    # Table identifier and projection are server-controlled registry values.
    order_by = ", ".join(f"`{c}`" for c in cfg["primary_keys"])\n    statement = f"SELECT {projection} FROM {table} ORDER BY {order_by} LIMIT {limit} OFFSET {offset}"
    response = sql_statement(statement, row_limit=min(limit, settings.max_read_rows))
    result = read_statement_result(response)
    if result["state"] not in ("SUCCEEDED", "UNKNOWN"):
        raise HTTPException(status_code=202, detail=result)
    return {"table": table_key, **result}


@app.get("/api/v1/jobs/{run_id}")
def job_status(run_id: int, _: None = Depends(require_api_key)):
    try:
        run = __import__("api.databricks", fromlist=["workspace_client"]).workspace_client().jobs.get_run(run_id=run_id)
        state = run.state
        result_state = getattr(getattr(state, "result_state", None), "value", None)
        response = {
            "run_id": run_id,
            "life_cycle_state": getattr(getattr(state, "life_cycle_state", None), "value", None),
            "result_state": result_state,
            "state_message": getattr(state, "state_message", None),
        }
        if result_state == "SUCCESS":
            output = __import__("api.databricks", fromlist=["workspace_client"]).workspace_client().jobs.get_run_output(run_id=run_id)
            response["notebook_output"] = getattr(getattr(output, "notebook_output", None), "result", None)
        return response
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Unable to retrieve job status") from exc
