# This registry is intentionally an allow-list. Do not accept arbitrary
# catalog/schema/table identifiers from callers.
TABLES = {
    "employees": {
        "full_name": "main.hr.employees",
        "primary_keys": ["employee_id"],
        "insert_required": ["employee_id", "employee_name"],
        "insert_allowed": ["employee_id", "employee_name", "salary", "department"],
        "update_allowed": ["employee_name", "salary", "department"],
        "read_allowed": ["employee_id", "employee_name", "salary", "department"],
        "enabled": True,
    },
    "customers": {
        "full_name": "main.crm.customers",
        "primary_keys": ["customer_id"],
        "insert_required": ["customer_id", "customer_name"],
        "insert_allowed": ["customer_id", "customer_name", "city", "email"],
        "update_allowed": ["customer_name", "city", "email"],
        "read_allowed": ["customer_id", "customer_name", "city", "email"],
        "enabled": True,
    },
}
