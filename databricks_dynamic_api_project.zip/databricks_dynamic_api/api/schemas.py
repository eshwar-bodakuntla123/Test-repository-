from typing import Any
from pydantic import BaseModel, ConfigDict, Field, model_validator


class InsertOneRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    data: dict[str, Any] = Field(min_length=1)


class InsertManyRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    records: list[dict[str, Any]] = Field(min_length=1, max_length=1000)


class UpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    primary_key: dict[str, Any] = Field(min_length=1)
    updates: dict[str, Any] = Field(min_length=1)

    @model_validator(mode="after")
    def keys_and_updates_must_be_disjoint(self):
        overlap = set(self.primary_key) & set(self.updates)
        if overlap:
            raise ValueError(f"Primary-key columns cannot be updated: {sorted(overlap)}")
        return self


class JobAccepted(BaseModel):
    status: str
    run_id: int
    table: str
    operation: str
