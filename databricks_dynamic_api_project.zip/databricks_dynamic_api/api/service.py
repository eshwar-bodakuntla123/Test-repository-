import json
import re
from typing import Any

from fastapi import HTTPException
from api.databricks import workspace_client
from api.registry import TABLES
from api.settings import settings


IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def table_config(table_key: str) -> dict:
    cfg = TABLES.get(table_key)
    if not cfg or not cfg.get("enabled"):
        raise HTTPException(status_code=404, detail="Table is not configured or is disabled")
    return cfg


def quoted_table_name(full_name: str) -> str:
    # Full name comes only from the trusted registry.
    parts = full_name.split(".")
    if len(parts) != 3 or not all(IDENTIFIER_RE.fullmatch(p) for p in parts):
        raise RuntimeError("Invalid table identifier in server configuration")
    return ".".join(f"`{p}`" for p in parts)


def get_table_metadata(table_key: str) -> dict:
    cfg = table_config(table_key)
    try:
        info = workspace_client().tables.get(full_name=cfg["full_name"])
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Unable to read Databricks table metadata") from exc

    columns = []
    for col in (getattr(info, "columns", None) or []):
        columns.append({
            "name": col.name,
            "type": getattr(col, "type_text", None) or str(getattr(col, "type_name", "UNKNOWN")),
            "nullable": getattr(col, "nullable", None),
            "comment": getattr(col, "comment", None),
        })

    return {
        "table": table_key,
        "full_name": cfg["full_name"],
        "columns": columns,
        "primary_keys": cfg["primary_keys"],
        "allowed_operations": ["insert", "update", "read"],
    }


def validate_record(table_key: str, record: dict[str, Any], mode: str, metadata: dict | None = None):
    cfg = table_config(table_key)
    allowed = set(cfg["insert_allowed"] if mode == "insert" else cfg["update_allowed"])
    unknown = set(record) - allowed
    if unknown:
        raise HTTPException(status_code=422, detail={"message": "Columns are not allowed", "columns": sorted(unknown)})

    if metadata is not None:
        actual = {c["name"] for c in metadata["columns"]}
        absent = set(record) - actual
        if absent:
            raise HTTPException(status_code=422, detail={"message": "Columns do not exist in target table", "columns": sorted(absent)})

    if mode == "insert":
        missing = set(cfg["insert_required"]) - set(record)
        if missing:
            raise HTTPException(status_code=422, detail={"message": "Required insert columns are missing", "columns": sorted(missing)})


def validate_primary_key(table_key: str, keys: dict, metadata: dict | None = None):
    cfg = table_config(table_key)
    expected = set(cfg["primary_keys"])
    if set(keys) != expected:
        raise HTTPException(status_code=422, detail={"message": "Primary key fields do not match configuration", "expected": sorted(expected)})
    if any(v is None for v in keys.values()):
        raise HTTPException(status_code=422, detail="Primary key values cannot be null")
    if metadata is not None:
        actual = {c["name"] for c in metadata["columns"]}
        if not expected.issubset(actual):
            raise HTTPException(status_code=500, detail="Configured primary key is not present in table schema")


def trigger_write_job(table_key: str, operation: str, records: list[dict], primary_key: dict | None = None):
    cfg = table_config(table_key)
    params = {
        "table_key": table_key,
        "operation": operation,
        "records_json": json.dumps(records, separators=(",", ":"), default=str),
        "primary_key_json": json.dumps(primary_key or {}, separators=(",", ":"), default=str),
    }
    if len(json.dumps(params).encode("utf-8")) > 9000:
        raise HTTPException(status_code=413, detail="Request is too large for job parameters; use a volume-backed batch upload")
    try:
        run = workspace_client().jobs.run_now(
            job_id=settings.databricks_job_id,
            job_parameters=params,
        )
        return {"status": "SUBMITTED", "run_id": run.run_id, "table": table_key, "operation": operation}
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Could not submit Databricks job") from exc


def sql_statement(statement: str, parameters: list[dict] | None = None, row_limit: int = 500):
    client = workspace_client()
    try:
        response = client.statement_execution.execute(
            statement=statement,
            warehouse_id=settings.databricks_warehouse_id,
            wait_timeout="10s",
            on_wait_timeout="CONTINUE",
            format="JSON_ARRAY",
            disposition="INLINE",
            parameters=parameters or [],
            row_limit=row_limit,
        )
        return response
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Databricks SQL execution failed") from exc


def read_statement_result(response):
    status = getattr(response, "status", None)
    state = getattr(status, "state", None) if status else None
    if state and getattr(state, "value", state) != "SUCCEEDED":
        return {"statement_id": getattr(response, "statement_id", None), "state": getattr(state, "value", state), "data": []}

    manifest = getattr(response, "manifest", None)
    schema = getattr(manifest, "schema", None) if manifest else None
    cols = [c.name for c in (getattr(schema, "columns", None) or [])]
    result = getattr(response, "result", None)
    rows = getattr(result, "data_array", None) if result else None
    data = [dict(zip(cols, row)) for row in (rows or [])]
    return {
        "statement_id": getattr(response, "statement_id", None),
        "state": getattr(state, "value", state) if state else "UNKNOWN",
        "data": data,
        "truncated": getattr(result, "truncated", False) if result else False,
    }
