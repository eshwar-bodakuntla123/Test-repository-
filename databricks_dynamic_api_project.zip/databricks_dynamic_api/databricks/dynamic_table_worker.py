# Upload this file to the Databricks workspace as a Python notebook, then configure
# the Databricks Job to run it as a notebook task.
import json
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.types import StructType


dbutils.widgets.text("table_key", "")
dbutils.widgets.text("operation", "")
dbutils.widgets.text("records_json", "[]")
dbutils.widgets.text("primary_key_json", "{}")

TABLES = {
    "employees": {
        "full_name": "main.hr.employees",
        "primary_keys": ["employee_id"],
        "insert_required": ["employee_id", "employee_name"],
        "insert_allowed": ["employee_id", "employee_name", "salary", "department"],
        "update_allowed": ["employee_name", "salary", "department"],\n        "read_allowed": ["employee_id", "employee_name", "salary", "department"],
    },
    "customers": {
        "full_name": "main.crm.customers",
        "primary_keys": ["customer_id"],
        "insert_required": ["customer_id", "customer_name"],
        "insert_allowed": ["customer_id", "customer_name", "city", "email"],
        "update_allowed": ["customer_name", "city", "email"],\n        "read_allowed": ["customer_id", "customer_name", "city", "email"],
    },
}


def quote_table_name(name: str) -> str:
    parts = name.split(".")
    if len(parts) != 3 or not all(p.replace("_", "").isalnum() for p in parts):
        raise ValueError("Invalid configured Unity Catalog table name")
    return ".".join(f"`{p}`" for p in parts)


def validate_and_build_df(table_name: str, record: dict, allowed: list, required: list | None = None):
    if not record:
        raise ValueError("Record cannot be empty")
    unknown = set(record) - set(allowed)
    if unknown:
        raise ValueError(f"Columns are not allowed: {sorted(unknown)}")
    if required:
        missing = set(required) - set(record)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

    target_schema = spark.table(table_name).schema
    fields_by_name = {f.name: f for f in target_schema.fields}
    absent = set(record) - set(fields_by_name)
    if absent:
        raise ValueError(f"Columns not found in target schema: {sorted(absent)}")

    # Build a one-row source dataframe using target field types, including null values.
    selected_fields = [fields_by_name[c] for c in record]
    schema = StructType(selected_fields)
    values = [record[c] for c in record]
    return spark.createDataFrame([tuple(values)], schema=schema)


def run():
    table_key = dbutils.widgets.get("table_key")
    operation = dbutils.widgets.get("operation").lower()
    records = json.loads(dbutils.widgets.get("records_json"))
    primary_key = json.loads(dbutils.widgets.get("primary_key_json"))

    if table_key not in TABLES:
        raise ValueError("Table is not configured")
    cfg = TABLES[table_key]
    target_name = cfg["full_name"]
    target = quote_table_name(target_name)

    if not spark.catalog.tableExists(target_name):
        raise ValueError(f"Target table does not exist: {target_name}")

    if operation == "insert":
        if not records:
            raise ValueError("No records supplied")
        for record in records:
            source = validate_and_build_df(
                target_name, record, cfg["insert_allowed"], cfg["insert_required"]
            )
            # MERGE with only WHEN NOT MATCHED INSERT gives insert-if-absent semantics.
            # It never updates an existing row. Delta does not enforce unique keys;
            # serialize competing inserts for the same key if strict uniqueness is required.
            condition = " AND ".join(
                f"t.`{k}` <=> s.`{k}`" for k in cfg["primary_keys"]
            )
            insert_cols = list(record.keys())
            values = {c: F.col(f"s.`{c}`") for c in insert_cols}
            (
                DeltaTable.forName(spark, target_name)
                .alias("t")
                .merge(source.alias("s"), condition)
                .whenNotMatchedInsert(values=values)
                .execute()
            )

    elif operation == "read":
        if len(records) != 1:
            raise ValueError("Read requires one options object")
        options = records[0]
        limit = max(1, min(int(options.get("limit", 100)), 500))
        offset = max(0, int(options.get("offset", 0)))
        read_columns = cfg["read_allowed"]
        projection = ", ".join(f"`{c}`" for c in read_columns)
        rows = (
            spark.table(target_name)
            .select(*read_columns)
            .limit(offset + limit)
            .collect()
        )
        page = rows[offset:offset + limit]
        payload = {
            "status": "COMPLETED",
            "table": target_name,
            "operation": "read",
            "data": [r.asDict(recursive=True) for r in page],
        }
        dbutils.notebook.exit(json.dumps(payload, default=str))

    elif operation == "update":
        if len(records) != 1:
            raise ValueError("Update requires exactly one updates object")
        if set(primary_key) != set(cfg["primary_keys"]):
            raise ValueError("Primary key fields do not match table configuration")
        if any(v is None for v in primary_key.values()):
            raise ValueError("Primary key values cannot be null")

        updates = records[0]
        if not updates:
            raise ValueError("No update fields supplied")
        if set(updates) & set(cfg["primary_keys"]):
            raise ValueError("Primary key columns cannot be updated")

        combined = {**primary_key, **updates}
        source = validate_and_build_df(
            target_name, combined,
            cfg["insert_allowed"], None
        )
        condition = " AND ".join(
            f"t.`{k}` <=> s.`{k}`" for k in cfg["primary_keys"]
        )
        update_values = {c: F.col(f"s.`{c}`") for c in updates}
        (
            DeltaTable.forName(spark, target_name)
            .alias("t")
            .merge(source.alias("s"), condition)
            .whenMatchedUpdate(set=update_values)
            .execute()
        )
    else:
        raise ValueError("Unsupported operation. Only insert and update are enabled.")

    return {"status": "COMPLETED", "table": target_name, "operation": operation}


result = run()
print(json.dumps(result))
