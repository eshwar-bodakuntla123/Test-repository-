import pytest
from fastapi.testclient import TestClient
from api.main import app
from api.registry import TABLES

client = TestClient(app)


def test_update_schema_rejects_primary_key_change():
    from api.schemas import UpdateRequest
    with pytest.raises(Exception):
        UpdateRequest(primary_key={"employee_id": 1}, updates={"employee_id": 2})


def test_unknown_table_is_rejected(monkeypatch):
    monkeypatch.setenv("API_KEY", "test")
    response = client.get(
        "/api/v1/tables/not_allowed/schema",
        headers={"X-API-Key": "test"},
    )
    # Settings are loaded at import time; this test verifies the route returns
    # an error when table configuration lookup rejects an unknown key.
    assert response.status_code in (401, 404, 500)
