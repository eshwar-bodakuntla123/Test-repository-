# NESO Metadata-Driven Unity Catalog API

React + FastAPI + one reusable Databricks Job for metadata-driven table discovery and generic Delta operations.

## Included
- Discover tables and columns from Unity Catalog within configured catalog/schema scopes.
- React UI builds table/column controls from discovered metadata.
- Generic single/batch INSERT and partial UPDATE.
- Generic bounded READ through the reusable Job.
- Primary-key mapping stored in a small metadata table (`framework.table_keys`) only when a table has no usable declared key metadata.
- No DELETE endpoint.
- One reusable Databricks notebook Job; no per-table Job and no per-table Python code.

## Critical design facts
1. Unity Catalog metadata discovery is not the same as authorization. `ALLOWED_SCHEMAS` limits discovery, and the Job worker checks the same scope. Add Entra ID/OAuth and user-level authorization before production.
2. Databricks primary-key constraints are informational, not enforced. Do not assume uniqueness. Use verified keys and concurrency controls.
3. The worker reads fallback keys from `framework.table_keys`. Populate this only after confirming keys are unique.
4. Multi-table requests are not atomic. Each Delta table operation commits independently; partial success is possible.
5. This starter passes bounded JSON in Job parameters and returns bounded notebook output. It is for small/medium requests and demonstrations. For large payloads/results, stage data in a Unity Catalog Volume/cloud object storage and use set-based MERGE.
6. Read endpoint uses Job mode, so it is asynchronous. Poll the job endpoint. It is intentionally bounded by `MAX_READ_ROWS`.
7. Insert uses append. Update uses MERGE and updates only supplied columns. No upsert/insert-on-missing behavior.
8. The code is a deployable starter, not a production-certified service. Test against a non-production workspace and align SDK versions/runtime with your workspace.

## 1. Configure environment
Copy `backend/.env.example` to `.env` for local testing. Set:
- `DATABRICKS_HOST`
- `DATABRICKS_TOKEN` (local development only)
- `DATABRICKS_JOB_ID`
- `ALLOWED_SCHEMAS` as comma-separated `catalog.schema` entries, e.g. `main.transmission,main.framework`
- `KEY_METADATA_TABLE`, e.g. `main.framework.table_keys`
- `API_KEY` only for controlled local testing

In deployed Databricks Apps, prefer app-managed OAuth/service-principal authentication. Do not put a personal PAT in the deployed app.

## 2. Create metadata schema/table
Run `sql/framework_metadata.sql`. Example:
```sql
CREATE SCHEMA IF NOT EXISTS main.framework;
CREATE TABLE IF NOT EXISTS main.framework.table_keys (
  table_name STRING NOT NULL,
  key_columns ARRAY<STRING> NOT NULL,
  enabled BOOLEAN
) USING DELTA;
```
Add verified key mappings, for example:
```sql
INSERT INTO main.framework.table_keys VALUES
('main.transmission.transmission_projects', array('project_id'), true);
```
Only add mappings after checking that the key is unique and non-null. This table is optional when the workspace metadata exposes a usable primary-key constraint; fallback is used when it does not.

## 3. Create the reusable Job
1. Upload `backend/databricks/dynamic_table_worker.py` to Workspace as a Python notebook.
2. Create one Job with this notebook as its task.
3. The notebook reads a `payload_json` widget.
4. Set Job Run-as to a dedicated service principal.
5. Grant that identity `USE CATALOG`, `USE SCHEMA`, and required table privileges (`SELECT`, `MODIFY`) only for approved scopes/tables.
6. Copy Job ID and configure `DATABRICKS_JOB_ID`.
7. Give the API app identity permission to run the Job (`CAN_MANAGE_RUN`). If the app exposes schema discovery, it also needs Unity Catalog metadata permissions on approved schemas.

## 4. Run locally
Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows; use cp on macOS/Linux
uvicorn api.main:app --reload --port 8000
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL. Vite proxies `/api` to localhost:8000.

## 5. React build and hosting
```bash
cd frontend
npm install
npm run build
```
Copy `frontend/dist` into `backend/static`. Deploy FastAPI with the static folder, or host React separately and set `VITE_API_BASE_URL` to the API origin. For Databricks Apps, upload the backend folder including `static`, `api`, `app.yaml`, `requirements.txt`, and `run.py`, then configure the Job resource in `app.yaml`.

## 6. API
- `GET /health`
- `GET /api/v1/catalogs`
- `GET /api/v1/schemas?catalog=main`
- `GET /api/v1/tables?catalog=main&schema=transmission`
- `GET /api/v1/tables/{catalog}/{schema}/{table}/schema`
- `POST /api/v1/operations` with operation `insert`, `update`, or `read`
- `GET /api/v1/jobs/{run_id}`

### Example insert
```json
{
  "request_id":"NESO-INS-1",
  "operation":"insert",
  "tables":[
    {
      "table_name":"main.transmission.transmission_projects",
      "records":[
        {"project_id":1001,"project_name":"North Link","capacity_mw":450.50}
      ]
    }
  ]
}
```

### Example partial update
```json
{
  "request_id":"NESO-UPD-1",
  "operation":"update",
  "tables":[
    {
      "table_name":"main.transmission.transmission_projects",
      "records":[
        {"keys":{"project_id":1001},"updates":{"status":"Approved"}},
        {"keys":{"project_id":1002},"updates":{"capacity_mw":275.25,"status":"In Progress"}}
      ]
    }
  ]
}
```

### Example read
```json
{
  "request_id":"NESO-READ-1",
  "operation":"read",
  "tables":[
    {
      "table_name":"main.transmission.transmission_projects",
      "filters":{"status":"Approved"},
      "columns":["project_id","project_name","status"],
      "limit":100
    }
  ]
}
```

## Production checklist
- Replace API-key starter auth with Entra ID OAuth/JWT and role-based authorization. A browser-held API key is not a production secret.
- Ensure the App identity and Job Run-as identity have separate least-privilege grants.
- Add request size limits, rate limiting, audit persistence, idempotency, retry strategy, monitoring and integration tests.
- Confirm primary-key uniqueness, nullability and concurrency policy.
- For large data, stage payloads/results in UC Volumes or cloud storage rather than notebook parameters/output.
- Decide whether insert duplicates should be rejected, ignored, or allowed. This starter appends.
- Add column-level data classification/PII controls appropriate to NESO.
