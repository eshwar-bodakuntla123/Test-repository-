import os
from functools import lru_cache

def env_list(name, default=""):
    return [x.strip() for x in os.getenv(name, default).split(",") if x.strip()]

def allowed_schemas():
    # Require explicit scope configuration; never discover every workspace table by default.
    return set(env_list("ALLOWED_SCHEMAS"))

def key_metadata_table():
    return os.getenv("KEY_METADATA_TABLE", "main.framework.table_keys")

def max_read_rows():
    return max(1, min(int(os.getenv("MAX_READ_ROWS", "200")), 1000))
