import os, json
from databricks.sdk import WorkspaceClient

def client():
    host, token = os.getenv("DATABRICKS_HOST"), os.getenv("DATABRICKS_TOKEN")
    if host and token:
        return WorkspaceClient(host=host, token=token)  # local development only
    return WorkspaceClient()  # Databricks Apps managed OAuth in deployed environment

def submit_job(payload: dict):
    job_id = int(os.environ["DATABRICKS_JOB_ID"])
    run = client().jobs.run_now(
        job_id=job_id,
        notebook_params={"payload_json": json.dumps(payload, separators=(",", ":"), default=str)}
    )
    return {"run_id": run.run_id, "job_id": job_id, "state": "PENDING"}

def get_job(run_id: int):
    run = client().jobs.get_run(run_id=run_id)
    state = run.state
    return {
        "run_id": run.run_id,
        "job_id": run.job_id,
        "life_cycle_state": state.life_cycle_state.value if state and state.life_cycle_state else None,
        "result_state": state.result_state.value if state and state.result_state else None,
        "state_message": state.state_message if state else None
    }
