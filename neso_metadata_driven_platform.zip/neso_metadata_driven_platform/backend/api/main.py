import os
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from .security import require_api_key
from .schemas import OperationRequest
from .metadata import list_catalogs, list_schemas, list_tables, get_schema, ensure_scope
from .databricks import submit_job, get_job

app = FastAPI(title="NESO Metadata-Driven Delta API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if x.strip()],
    allow_credentials=False, allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["*"]
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/api/v1/catalogs", dependencies=[Depends(require_api_key)])
def catalogs():
    return list_catalogs()

@app.get("/api/v1/schemas", dependencies=[Depends(require_api_key)])
def schemas(catalog: str):
    return list_schemas(catalog)

@app.get("/api/v1/tables", dependencies=[Depends(require_api_key)])
def tables(catalog: str, schema: str):
    return list_tables(catalog, schema)

@app.get("/api/v1/tables/{catalog}/{schema}/{table}/schema", dependencies=[Depends(require_api_key)])
def table_schema(catalog: str, schema: str, table: str):
    return get_schema(catalog, schema, table)

@app.post("/api/v1/operations", dependencies=[Depends(require_api_key)])
def operations(request: OperationRequest):
    body = request.model_dump(exclude_none=True)
    for item in body["tables"]:
        ensure_scope(item["table_name"])
    try:
        return submit_job(body)
    except Exception as e:
        raise HTTPException(502, f"Could not submit Databricks Job: {e}")

@app.get("/api/v1/jobs/{run_id}", dependencies=[Depends(require_api_key)])
def job_status(run_id: int):
    try:
        return get_job(run_id)
    except Exception as e:
        raise HTTPException(502, f"Could not get Databricks Job status: {e}")

static_dir = Path(__file__).resolve().parent.parent / "static"
if static_dir.exists():
    app.mount("/assets", StaticFiles(directory=static_dir / "assets"), name="assets")
    @app.get("/")
    def frontend():
        return FileResponse(static_dir / "index.html")
