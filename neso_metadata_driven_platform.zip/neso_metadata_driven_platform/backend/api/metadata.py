from fastapi import HTTPException
from .config import allowed_schemas
from .databricks import client

def ensure_scope(full_name: str):
    parts = full_name.split(".")
    if len(parts) != 3:
        raise HTTPException(400, "Use a fully qualified catalog.schema.table name")
    scope = ".".join(parts[:2])
    if scope not in allowed_schemas():
        raise HTTPException(403, f"Catalog/schema is outside configured scope: {scope}")
    return parts

def list_catalogs():
    # Return only catalogs that contain configured allowed schemas.
    scopes = allowed_schemas()
    return sorted({s.split(".")[0] for s in scopes})

def list_schemas(catalog: str):
    scopes = allowed_schemas()
    if catalog not in {s.split(".")[0] for s in scopes}:
        raise HTTPException(403, "Catalog is outside configured scope")
    return sorted(s.split(".")[1] for s in scopes if s.split(".")[0] == catalog)

def list_tables(catalog: str, schema: str):
    if f"{catalog}.{schema}" not in allowed_schemas():
        raise HTTPException(403, "Schema is outside configured scope")
    try:
        return [
            {"name": t.name, "full_name": f"{catalog}.{schema}.{t.name}", "table_type": str(t.table_type)}
            for t in client().tables.list(catalog_name=catalog, schema_name=schema)
        ]
    except Exception as e:
        raise HTTPException(502, f"Unity Catalog table discovery failed: {e}")

def get_schema(catalog: str, schema: str, table: str):
    full = f"{catalog}.{schema}.{table}"
    ensure_scope(full)
    try:
        info = client().tables.get(full_name=full)
        cols = info.columns or []
        return {
            "table_name": full,
            "columns": [
                {"name": c.name, "type_text": c.type_text, "nullable": c.nullable,
                 "comment": c.comment}
                for c in cols
            ],
            "properties": info.properties or {},
            "table_type": str(info.table_type)
        }
    except Exception as e:
        raise HTTPException(502, f"Unity Catalog schema lookup failed: {e}")
