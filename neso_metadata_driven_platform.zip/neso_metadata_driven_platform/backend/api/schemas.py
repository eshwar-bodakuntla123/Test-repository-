from typing import Any, Literal
from pydantic import BaseModel, Field, ConfigDict, model_validator

class TableOperation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    table_name: str
    records: list[dict[str, Any]] | None = None
    filters: dict[str, Any] | None = None
    columns: list[str] | None = None
    limit: int | None = Field(default=100, ge=1, le=1000)

class OperationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    request_id: str = Field(min_length=1, max_length=120)
    operation: Literal["insert", "update", "read"]
    tables: list[TableOperation] = Field(min_length=1, max_length=50)

    @model_validator(mode="after")
    def validate_shape(self):
        names = [t.table_name.lower() for t in self.tables]
        if len(names) != len(set(names)):
            raise ValueError("Each table may appear once per request; group its records")
        for t in self.tables:
            if self.operation in ("insert", "update") and not t.records:
                raise ValueError(f"{self.operation} requires records for {t.table_name}")
            if self.operation == "read" and t.records is not None:
                raise ValueError("read uses filters/columns/limit, not records")
        return self
