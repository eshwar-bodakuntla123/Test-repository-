import os
from fastapi import Header, HTTPException

async def require_api_key(x_api_key: str | None = Header(default=None)):
    # Local/internal starter only. Replace with Entra ID OAuth/JWT and role checks for production.
    expected = os.getenv("API_KEY")
    if expected and x_api_key != expected:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
