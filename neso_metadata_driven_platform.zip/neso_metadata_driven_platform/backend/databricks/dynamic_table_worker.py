# Databricks Python notebook source
# One reusable Job for insert, update, and bounded read operations.
import json, os
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.types import StructType

dbutils.widgets.text("payload_json", "{}")
payload = json.loads(dbutils.widgets.get("payload_json"))

ALLOWED_SCHEMAS = {
    x.strip() for x in os.getenv("ALLOWED_SCHEMAS", "main.transmission,main.framework").split(",") if x.strip()
}
KEY_METADATA_TABLE = os.getenv("KEY_METADATA_TABLE", "main.framework.table_keys")
MAX_READ_ROWS = int(os.getenv("MAX_READ_ROWS", "200"))

def quote_ident(s):
    return "`" + s.replace("`", "``") + "`"

def validate_table(name):
    parts = name.split(".")
    if len(parts) != 3 or ".".join(parts[:2]) not in ALLOWED_SCHEMAS:
        raise ValueError("Table is outside configured catalog/schema scope")
    return spark.table(name)

def resolve_keys(table_name, df):
    # Prefer a verified key mapping. UC PK metadata can be added here if your
    # workspace/runtime exposes constraint metadata reliably.
    if not spark.catalog.tableExists(KEY_METADATA_TABLE):
        raise ValueError(f"No key metadata table {KEY_METADATA_TABLE}; configure verified keys before UPDATE")
    rows = (spark.table(KEY_METADATA_TABLE)
            .where((F.col("table_name") == table_name) & (F.coalesce(F.col("enabled"), F.lit(True))))
            .select("key_columns").limit(2).collect())
    if len(rows) != 1:
        raise ValueError(f"Expected exactly one enabled key mapping for {table_name}")
    keys = rows[0]["key_columns"]
    if not keys or not set(keys).issubset(set(df.columns)):
        raise ValueError("Configured key columns are missing from target table")
    return keys

def validate_columns(df, cols):
    missing = set(cols) - set(df.columns)
    if missing:
        raise ValueError(f"Columns not found in target schema: {sorted(missing)}")

def cast_record(record, schema):
    # Spark performs conversion to the actual target schema. Invalid casts fail the row.
    fields = {f.name: f for f in schema.fields}
    names = list(record.keys())
    validate_columns_schema = set(names) - set(fields)
    if validate_columns_schema:
        raise ValueError(f"Unknown columns: {sorted(validate_columns_schema)}")
    source_schema = StructType([fields[n] for n in names])
    return spark.createDataFrame([tuple(record[n] for n in names)], schema=source_schema)

results = []
for table_spec in payload["tables"]:
    table_name = table_spec["table_name"]
    tr = {"table_name": table_name, "operation": payload["operation"]}
    try:
        target = validate_table(table_name)
        schema = target.schema
        if payload["operation"] == "insert":
            rows = table_spec["records"]
            if not rows:
                raise ValueError("No records supplied")
            source = spark.createDataFrame(rows, schema=schema)  # strict schema alignment; all schema fields expected
            source.write.format("delta").mode("append").saveAsTable(table_name)
            tr.update({"status": "success", "inserted_submitted_rows": len(rows)})
        elif payload["operation"] == "update":
            keys = resolve_keys(table_name, target)
            row_results = []
            for idx, record in enumerate(table_spec["records"]):
                try:
                    record_keys = record.get("keys", {})
                    updates = record.get("updates", {})
                    if set(record_keys) != set(keys):
                        raise ValueError(f"keys must contain exactly {keys}")
                    if not updates:
                        raise ValueError("updates cannot be empty")
                    if set(updates) & set(keys):
                        raise ValueError("Primary key columns cannot be updated")
                    validate_columns(target, list(record_keys) + list(updates))
                    combined = {**record_keys, **updates}
                    src = cast_record(combined, schema)
                    condition = " AND ".join([f"t.{quote_ident(k)} = s.{quote_ident(k)}" for k in keys])
                    set_expr = {c: F.col(f"s.{quote_ident(c)}") for c in updates}
                    (DeltaTable.forName(spark, table_name).alias("t")
                     .merge(src.alias("s"), condition)
                     .whenMatchedUpdate(set=set_expr)
                     .execute())
                    row_results.append({"row": idx, "status": "merge_executed",
                                        "note": "Existing matching row updated if key matched; no insert"})
                except Exception as e:
                    row_results.append({"row": idx, "status": "failed", "error": str(e)})
            tr.update({"status": "processed", "records": row_results})
        elif payload["operation"] == "read":
            selected = table_spec.get("columns") or target.columns
            validate_columns(target, selected)
            query = target.select(*[F.col(quote_ident(c)) for c in selected])
            filters = table_spec.get("filters", {})
            for col, value in filters.items():
                validate_columns(target, [col])
                query = query.where(F.col(quote_ident(col)) == F.lit(value))
            limit = min(int(table_spec.get("limit", 100)), MAX_READ_ROWS)
            data = [r.asDict(recursive=True) for r in query.limit(limit).collect()]
            tr.update({"status": "success", "columns": selected, "rows": data, "row_count": len(data)})
        else:
            raise ValueError("Unsupported operation")
    except Exception as e:
        tr.update({"status": "failed", "error": str(e)})
    results.append(tr)

dbutils.notebook.exit(json.dumps({
    "request_id": payload.get("request_id"),
    "operation": payload.get("operation"),
    "table_results": results,
    "warning": "Multi-table operations are not atomic. Review per-table and per-row outcomes."
}, default=str))
