import React,{useEffect,useState} from "react";
import{createRoot}from"react-dom/client";
import"./style.css";
const API=import.meta.env.VITE_API_BASE_URL||"";
function App(){
 const [apiKey,setApiKey]=useState(""),[catalogs,setCatalogs]=useState([]),[catalog,setCatalog]=useState(""),[schemas,setSchemas]=useState([]),[schema,setSchema]=useState(""),[tables,setTables]=useState([]),[table,setTable]=useState(""),[meta,setMeta]=useState(null),[op,setOp]=useState("update"),[records,setRecords]=useState("[]"),[filters,setFilters]=useState("{}"),[columns,setColumns]=useState(""),[limit,setLimit]=useState(100),[run,setRun]=useState(""),[status,setStatus]=useState(null),[err,setErr]=useState(""),[busy,setBusy]=useState(false);
 const headers={"Content-Type":"application/json",...(apiKey?{"X-API-Key":apiKey}:{})};
 async function call(path,opts={}){let r=await fetch(API+path,{...opts,headers:{...headers,...opts.headers}});let b=await r.json().catch(()=>({}));if(!r.ok)throw Error(b.detail||`HTTP ${r.status}`);return b}
 async function loadCatalogs(){try{let x=await call("/api/v1/catalogs");setCatalogs(x);if(x.length)setCatalog(x[0])}catch(e){setErr(e.message)}}
 useEffect(()=>{loadCatalogs()},[]);
 useEffect(()=>{if(catalog)call(`/api/v1/schemas?catalog=${encodeURIComponent(catalog)}`).then(x=>{setSchemas(x);setSchema(x[0]||"")}).catch(e=>setErr(e.message))},[catalog]);
 useEffect(()=>{if(catalog&&schema)call(`/api/v1/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`).then(x=>{setTables(x);setTable(x[0]?.name||"")}).catch(e=>setErr(e.message))},[catalog,schema]);
 useEffect(()=>{if(catalog&&schema&&table)call(`/api/v1/tables/${catalog}/${schema}/${table}/schema`).then(x=>{setMeta(x);setColumns(x.columns.map(c=>c.name).join(", "))}).catch(e=>setErr(e.message))},[catalog,schema,table]);
 async function submit(){setBusy(true);setErr("");try{let full=`${catalog}.${schema}.${table}`,spec={table_name:full};if(op==="read"){spec.filters=JSON.parse(filters);spec.columns=columns.split(",").map(x=>x.trim()).filter(Boolean);spec.limit=Number(limit)}else{spec.records=JSON.parse(records)}let x=await call("/api/v1/operations",{method:"POST",body:JSON.stringify({request_id:"NESO-"+Date.now(),operation:op,tables:[spec]})});setRun(String(x.run_id));setStatus(x)}catch(e){setErr(e.message)}finally{setBusy(false)}}
 async function poll(){try{setStatus(await call(`/api/v1/jobs/${run}`))}catch(e){setErr(e.message)}}
 return <div className="app"><header><div><small>NESO · METADATA-DRIVEN DATA PLATFORM</small><h1>Transmission Data Operations</h1><p>Discover Unity Catalog tables and operate without hardcoded table schemas.</p></div><span>INSERT · READ · UPDATE</span></header>
 <div className="auth"><label>API key <input type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="Local/internal testing only"/></label><button className="light" onClick={loadCatalogs}>Refresh metadata</button></div>
 {err&&<div className="error">{err}</div>}
 <main><aside><h2>Unity Catalog discovery</h2><label>Catalog<select value={catalog} onChange={e=>setCatalog(e.target.value)}>{catalogs.map(x=><option key={x}>{x}</option>)}</select></label><label>Schema<select value={schema} onChange={e=>setSchema(e.target.value)}>{schemas.map(x=><option key={x}>{x}</option>)}</select></label><label>Table<select value={table} onChange={e=>setTable(e.target.value)}>{tables.map(x=><option key={x.name} value={x.name}>{x.name}</option>)}</select></label>
 {meta&&<><h3>Discovered columns</h3><div className="col-list">{meta.columns.map(c=><div key={c.name}><code>{c.name}</code><small>{c.type_text}{c.nullable===false?" · NOT NULL":""}</small></div>)}</div></>}</aside>
 <section><h2>Operation</h2><div className="op">{["insert","read","update"].map(x=><button key={x} className={op===x?"selected":"light"} onClick={()=>setOp(x)}>{x.toUpperCase()}</button>)}</div>
 {op==="read"?<><label>Columns (comma separated; blank means all)<input value={columns} onChange={e=>setColumns(e.target.value)} placeholder="project_id, project_name, status"/></label><label>Equality filters JSON<textarea className="smallarea" value={filters} onChange={e=>setFilters(e.target.value)}/></label><label>Maximum rows<input type="number" min="1" max="1000" value={limit} onChange={e=>setLimit(e.target.value)}/></label></>:<><p className="hint">{op==="insert"?"Enter an array of records. Include all required non-null columns without defaults.":"Enter an array of records. Each update record must contain keys and updates. Key columns are resolved from the metadata table."}</p><textarea value={records} onChange={e=>setRecords(e.target.value)} spellCheck="false"/></>}
 <div className="actions"><button onClick={submit} disabled={busy||!table}>{busy?"Submitting…":`Submit ${op} Job`}</button><button className="light" onClick={poll} disabled={!run}>Refresh Job</button></div>
 {run&&<div className="status"><b>Run ID:</b> {run}<p>Lifecycle: {status?.life_cycle_state||"PENDING"}</p><p>Result: {status?.result_state||"Not completed"}</p><small>{status?.state_message}</small></div>}
 </section></main><footer>Discovery is restricted to configured catalog/schema scopes. Updates require verified key metadata. Multi-table requests are not atomic. No DELETE operation.</footer></div>
}
createRoot(document.getElementById("root")).render(<App/>);
