CREATE SCHEMA IF NOT EXISTS main.framework;

CREATE TABLE IF NOT EXISTS main.framework.table_keys (
  table_name STRING NOT NULL,
  key_columns ARRAY<STRING> NOT NULL,
  enabled BOOLEAN
)
USING DELTA;

-- Example only. Insert after verifying project_id is unique and non-null.
-- INSERT INTO main.framework.table_keys
-- VALUES ('main.transmission.transmission_projects', array('project_id'), true);
